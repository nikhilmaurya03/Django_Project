from django.urls import path
from . import views

urlpatterns = [
    path('createaccount/', views.members, name='createaccount'),
    path('submit', views.details, name='submit'),
    path('login/', views.members1, name='login'),
    path('yourdetails', views.members2, name='yourdetails'),
    
]