from django.contrib import admin
from .models import attendance,standard,schedule

# Register your models here.
admin.site.register(attendance)
admin.site.register(standard)
admin.site.register(schedule)
